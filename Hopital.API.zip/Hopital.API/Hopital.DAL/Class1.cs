﻿namespace Hopital.DAL
{
    public class Class1
    {

    }
}