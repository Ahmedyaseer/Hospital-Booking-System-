﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital.BLL
{
    public class DiseaseDto
    {
        public string diseaseName { get; set; } = "";
        public string diseaseDetails { get; set; } = "";

        public string diseasetreatment { get; set; } = "";
        public string doctorName { get; set; } = "";
    }
}
