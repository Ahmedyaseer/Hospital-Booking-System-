﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital.BLL
{
    public class DoctoreForDept
    {
        public string Id { get; set; }
        public string Name { get; set; } = "";
        public string ProfilePic { get; set; } = "";
        public string departmentname { get; set; } = "";
    }
}
