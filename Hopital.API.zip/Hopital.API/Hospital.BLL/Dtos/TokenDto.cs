﻿
namespace Hospital.BLL.Dtos;

public class TokenDto
{
    public string Token { get; set; } = string.Empty;
}
