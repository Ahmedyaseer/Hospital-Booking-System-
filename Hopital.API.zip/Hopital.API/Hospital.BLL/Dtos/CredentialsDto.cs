﻿

namespace Hospital.BLL;

public  class CredentialsDto
{
    public string userName { get; set; } = string.Empty;
    public string password { get; set; } = string.Empty;
}
