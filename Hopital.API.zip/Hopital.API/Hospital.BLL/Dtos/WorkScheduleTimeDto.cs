﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital.BLL
{
    public class WorkScheduleTimeDto
    {
        public TimeSpan time { get; set; }
        public bool status { get; set; }
    }
}
