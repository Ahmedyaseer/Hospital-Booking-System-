﻿namespace Hospital.BLL
{
    public class Class1
    {

    }
}