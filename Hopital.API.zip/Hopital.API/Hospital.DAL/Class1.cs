﻿namespace Hospital.DAL
{
    public class Class1
    {

    }
}