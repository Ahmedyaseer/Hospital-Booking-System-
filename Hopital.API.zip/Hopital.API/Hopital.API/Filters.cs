﻿namespace Hopital.API
{
    public class Filters
    {
    }
}
