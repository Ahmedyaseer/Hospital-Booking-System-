﻿namespace Hopital.API.Filter
{
    public class CheckBookExisitAtrribute
    {
    }
}
